#!/usr/bin/env python3
"""
Garmin Connect Data Fetcher - Retrieve health data from the Garmin Health MCP server

Usage:
    # Switch to a different user (rare — only to act as a different account)
    # Log in to your Garmin Connect account
    python3 garmin_data.py login --email EMAIL

    # Get daily activity summary (steps, HR, calories, distance)
    python3 garmin_data.py summary [--days N] [--start DATE] [--end DATE]

    # Get sleep data
    python3 garmin_data.py sleep [--days N] [--start DATE] [--end DATE]

    # Get most recent activities/workouts (filter by date client-side on `start_time`)
    python3 garmin_data.py activities [--limit N]

    # Get heart rate data
    python3 garmin_data.py heart_rate [--days N] [--start DATE] [--end DATE]

    # Get HRV data (single date; server returns weekly avg + last-night value)
    python3 garmin_data.py hrv [--date DATE]

    # Get stress data
    python3 garmin_data.py stress [--days N] [--start DATE] [--end DATE]

    # Get body battery data
    python3 garmin_data.py body_battery [--days N] [--start DATE] [--end DATE]

    # Get SpO2 data
    python3 garmin_data.py spo2 [--days N] [--start DATE] [--end DATE]

    # Get respiration data (single date)
    python3 garmin_data.py respiration [--date DATE]

    # Get body composition (weight, BMI, body fat)
    python3 garmin_data.py body_composition [--days N] [--start DATE] [--end DATE]

    # Get training readiness scores
    python3 garmin_data.py training_readiness [--days N] [--start DATE] [--end DATE]

    # Get registered devices
    python3 garmin_data.py devices

    # Get combined single-day health snapshot
    python3 garmin_data.py health_snapshot [--date DATE]

    # Get user profile
    python3 garmin_data.py profile

Output: JSON to stdout
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone

_AGENT_ENV_BASE = os.environ.get("AGENT_ENV_URL", "http://localhost:8000").rstrip("/")
AGENT_ENV_URL = _AGENT_ENV_BASE.removesuffix("/mcp")
_TOOL_ENDPOINT = "/step" if _AGENT_ENV_BASE.endswith("/mcp") else "/call-tool"


def _agent_env_headers() -> dict:
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "openclaw-skill/1.0",
    }
    cf_client_id = os.environ.get("CF_ACCESS_CLIENT_ID")
    cf_client_secret = os.environ.get("CF_ACCESS_CLIENT_SECRET")
    if cf_client_id and cf_client_secret:
        headers["CF-Access-Client-Id"] = cf_client_id
        headers["CF-Access-Client-Secret"] = cf_client_secret
    return headers


def _call_tool(tool_name: str, tool_args: dict = None) -> dict:
    """Call an MCP tool via the agent-environment API.

    Supports both legacy /call-tool and new /step endpoints.
    Payload format and response parsing adapt based on _TOOL_ENDPOINT.
    """
    if _TOOL_ENDPOINT == "/step":
        payload = json.dumps({
            "action": "call_tool",
            "tool_name": tool_name,
            "arguments": tool_args or {},
        }).encode("utf-8")
    else:
        payload = json.dumps({
            "tool_name": tool_name,
            "tool_args": tool_args or {},
        }).encode("utf-8")
    req = urllib.request.Request(
        f"{AGENT_ENV_URL}{_TOOL_ENDPOINT}",
        data=payload,
        headers=_agent_env_headers(),
        method="POST",
    )
    try:
        with urllib.request.urlopen(req) as resp:
            raw = json.loads(resp.read().decode("utf-8"))
            # /step wraps content in {"content": [...], "isError": bool}
            # /call-tool returns the content blocks array directly
            if isinstance(raw, dict) and "content" in raw:
                if raw.get("isError"):
                    return {"error": raw.get("error", "Unknown tool error")}
                content_blocks = raw["content"]
            elif isinstance(raw, list):
                content_blocks = raw
            else:
                content_blocks = raw.get("content", [])
            for block in content_blocks:
                if block.get("type") == "text":
                    try:
                        return json.loads(block["text"])
                    except json.JSONDecodeError:
                        return {"text": block["text"]}
            return {"content": content_blocks}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        return {"error": f"API error {e.code}: {body}"}
    except urllib.error.URLError as e:
        return {"error": f"Connection failed: {e.reason}"}


def _get_date_range(days=None, start=None, end=None, default_days=7):
    """Calculate start/end ISO date strings for API calls."""
    now = datetime.now(timezone.utc)
    if start:
        start_str = start
    elif days:
        start_str = (now - timedelta(days=days)).strftime("%Y-%m-%d")
    else:
        start_str = (now - timedelta(days=default_days)).strftime("%Y-%m-%d")
    end_str = end if end else now.strftime("%Y-%m-%d")
    return start_str, end_str


# ---- Helpers ----


def _compute_history_request(days=None, start=None, end=None, default=7):
    """Resolve --days/--start/--end into (days_to_fetch, filter_start, filter_end).

    The history-style MCP tools (e.g. garmin_health_get_sleep_history) only accept
    a `days` count and return the most-recent N records ordered by date desc. To
    honour a real date range we ask the server for enough records to reach back to
    `start`, then filter client-side to [start, end].

    Resolution rules:
      - no start, no end: fetch `days` or `default` records, no client filter
      - start given:     filter = [start, end or today]
      - end only:        filter = [end - (days or default - 1), end]
    """
    if not start and not end:
        return (days or default, None, None)

    now = datetime.now(timezone.utc)
    end_str = end or now.strftime("%Y-%m-%d")

    if start:
        start_str = start
    else:
        span = (days or default) - 1
        end_dt = datetime.strptime(end, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        start_str = (end_dt - timedelta(days=max(span, 0))).strftime("%Y-%m-%d")

    start_dt = datetime.strptime(start_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    days_to_fetch = max(int((now - start_dt).days) + 1, 1)
    return days_to_fetch, start_str, end_str


def _filter_history(response, list_key, start=None, end=None):
    """Filter response[list_key] to entries with `start <= date <= end` (ISO strings).

    No-op when both bounds are None, or when the response is not a successful
    payload (errors, raw text, etc.). On a successful payload that's missing the
    expected key, raises rather than silently returning unfiltered data — so the
    skill fails loudly if the server response shape ever drifts.

    Mutates and returns `response`; refreshes data_points and stamps start_date/end_date.
    """
    if not start and not end:
        return response
    if not (isinstance(response, dict) and response.get("success") is True):
        return response  # error / non-standard payload — leave as-is
    items = response.get(list_key)
    if not isinstance(items, list):
        raise RuntimeError(
            f"Garmin server returned an unexpected response: expected a "
            f"{list_key!r} field but got {sorted(response.keys())}."
        )

    def in_range(item):
        d = item.get("date") if isinstance(item, dict) else None
        if not d:
            return True  # keep entries with no date rather than silently dropping them
        if start and d < start:
            return False
        if end and d > end:
            return False
        return True

    filtered = [it for it in items if in_range(it)]
    response[list_key] = filtered
    response["data_points"] = len(filtered)
    if start:
        response["start_date"] = start
    if end:
        response["end_date"] = end
    return response


# ---- Public API functions ----


def get_summary(days=None, start=None, end=None):
    """Get daily activity summaries (steps, HR, calories, distance)."""
    start_str, end_str = _get_date_range(days, start, end)
    return _call_tool("garmin_health_get_daily_stats_range", {
        "start_date": start_str,
        "end_date": end_str,
    })


def get_sleep(days=None, start=None, end=None):
    """Get sleep data."""
    days_to_fetch, fstart, fend = _compute_history_request(days, start, end, default=7)
    result = _call_tool("garmin_health_get_sleep_history", {"days": days_to_fetch})
    return _filter_history(result, "sleep_history", fstart, fend)


def get_activities(limit=20):
    """Get most recent activities/workouts (server returns them in reverse-chronological order)."""
    return _call_tool("garmin_health_get_activities", {"limit": limit})


def get_heart_rate(days=None, start=None, end=None):
    """Get resting heart rate trend."""
    days_to_fetch, fstart, fend = _compute_history_request(days, start, end, default=30)
    result = _call_tool("garmin_health_get_resting_heart_rate_trend", {"days": days_to_fetch})
    return _filter_history(result, "trend", fstart, fend)


def get_hrv(date=None):
    """Get HRV data for a single date (server returns weekly average + last-night value)."""
    args = {"date": date} if date else {}
    return _call_tool("garmin_health_get_hrv", args)


def get_stress(days=None, start=None, end=None):
    """Get stress data."""
    days_to_fetch, fstart, fend = _compute_history_request(days, start, end, default=7)
    result = _call_tool("garmin_health_get_stress_history", {"days": days_to_fetch})
    return _filter_history(result, "stress_history", fstart, fend)


def get_body_battery(days=None, start=None, end=None):
    """Get body battery data."""
    days_to_fetch, fstart, fend = _compute_history_request(days, start, end, default=7)
    result = _call_tool("garmin_health_get_body_battery_history", {"days": days_to_fetch})
    return _filter_history(result, "body_battery_history", fstart, fend)


def get_spo2(days=None, start=None, end=None):
    """Get SpO2 data."""
    days_to_fetch, fstart, fend = _compute_history_request(days, start, end, default=7)
    result = _call_tool("garmin_health_get_spo2_history", {"days": days_to_fetch})
    return _filter_history(result, "spo2_history", fstart, fend)


def get_respiration(date=None):
    """Get respiration data for a single date."""
    args = {"date": date} if date else {}
    return _call_tool("garmin_health_get_respiration", args)


def get_body_composition(days=None, start=None, end=None):
    """Get body composition (weight, BMI, body fat) history."""
    days_to_fetch, fstart, fend = _compute_history_request(days, start, end, default=30)
    result = _call_tool("garmin_health_get_weight_history", {"days": days_to_fetch})
    return _filter_history(result, "weight_history", fstart, fend)


def get_training_readiness(days=None, start=None, end=None):
    """Get training readiness data."""
    days_to_fetch, fstart, fend = _compute_history_request(days, start, end, default=7)
    result = _call_tool("garmin_health_get_training_readiness_history", {"days": days_to_fetch})
    return _filter_history(result, "readiness_history", fstart, fend)


def get_devices():
    """Get registered Garmin devices."""
    return _call_tool("garmin_health_get_devices")


def get_profile():
    """Get user profile."""
    return _call_tool("garmin_health_get_current_user")


def get_health_snapshot(date=None):
    """Get a combined single-day health snapshot across all metrics."""
    args = {"date": date} if date else {}
    return _call_tool("garmin_health_get_health_snapshot", args)


def login(email):
    """Switch to a different user by email. Rarely needed — the account owner is pre-authenticated."""
    return _call_tool("garmin_health_login", {"email": email})


def main():
    parser = argparse.ArgumentParser(description="Fetch Garmin Connect health data")
    sub = parser.add_subparsers(dest="command")

    login_p = sub.add_parser("login", help="Switch to a different user (rare)")
    login_p.add_argument("--email", type=str, required=True)

    # Commands with date range support (server tool accepts a range or days count)
    date_range_cmds = [
        "summary", "sleep", "heart_rate",
        "stress", "body_battery", "spo2",
        "body_composition", "training_readiness",
    ]
    for cmd in date_range_cmds:
        p = sub.add_parser(cmd)
        p.add_argument("--days", type=int, default=7)
        p.add_argument("--start", help="ISO date (e.g., 2026-01-01)")
        p.add_argument("--end", help="ISO date")

    # Single-date commands (server tool only accepts a single `date`, defaults to today)
    single_date_cmds = ["hrv", "respiration", "health_snapshot"]
    for cmd in single_date_cmds:
        p = sub.add_parser(cmd)
        p.add_argument("--date", help="ISO date (e.g., 2026-01-01); defaults to today")

    # Activities: server only accepts a `limit` (no date filter). Filter the JSON
    # output by `start_time` client-side if a date range is needed.
    activities_p = sub.add_parser("activities")
    activities_p.add_argument("--limit", type=int, default=20, help="Max activities to return (most recent first)")

    # Commands without date range
    sub.add_parser("devices")
    sub.add_parser("profile")

    args = parser.parse_args()

    handlers = {
        "login": lambda: login(args.email),
        "summary": lambda: get_summary(args.days, args.start, args.end),
        "sleep": lambda: get_sleep(args.days, args.start, args.end),
        "activities": lambda: get_activities(args.limit),
        "heart_rate": lambda: get_heart_rate(args.days, args.start, args.end),
        "hrv": lambda: get_hrv(args.date),
        "stress": lambda: get_stress(args.days, args.start, args.end),
        "body_battery": lambda: get_body_battery(args.days, args.start, args.end),
        "spo2": lambda: get_spo2(args.days, args.start, args.end),
        "respiration": lambda: get_respiration(args.date),
        "body_composition": lambda: get_body_composition(args.days, args.start, args.end),
        "training_readiness": lambda: get_training_readiness(args.days, args.start, args.end),
        "devices": get_devices,
        "profile": get_profile,
        "health_snapshot": lambda: get_health_snapshot(args.date),
    }

    if args.command not in handlers:
        parser.print_help()
        sys.exit(1)

    result = handlers[args.command]()
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
