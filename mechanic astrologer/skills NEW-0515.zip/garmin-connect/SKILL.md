---
name: garmin-connect
description: Access Garmin Connect health and fitness data (daily activity, sleep, heart rate, HRV, stress, body battery, SpO2, training readiness, workouts, body composition). Use when the user asks about steps, heart rate, sleep quality, stress levels, body battery, training readiness, HRV trends, workout history, weight, or any Garmin health metrics.
---

# Garmin Connect

Query health and fitness data from Garmin Connect.

## Authentication

The account owner is pre-authenticated at startup — every subcommand works directly. To act as a different persona on a shared account (rare; e.g., a different family member), use `login`:

```bash
python3 {baseDir}/garmin_data.py login --email their@email.com
```

## Fetching Data

Use `garmin_data.py` to get JSON data:

```bash
# Daily activity summary (steps, HR, calories, distance)
python3 {baseDir}/garmin_data.py summary --days 7

# Sleep data (duration, quality, stages)
python3 {baseDir}/garmin_data.py sleep --days 14

# Activities/workouts — server returns the most recent N (no date filter; filter `start_time` client-side if needed)
python3 {baseDir}/garmin_data.py activities --limit 30

# Heart rate (resting, min, max, avg)
python3 {baseDir}/garmin_data.py heart_rate --days 14

# HRV (heart rate variability) — single date; response includes weekly average + last-night value
python3 {baseDir}/garmin_data.py hrv                  # today
python3 {baseDir}/garmin_data.py hrv --date 2026-01-15

# Stress levels
python3 {baseDir}/garmin_data.py stress --days 7

# Body battery
python3 {baseDir}/garmin_data.py body_battery --days 7

# SpO2 (blood oxygen)
python3 {baseDir}/garmin_data.py spo2 --days 7

# Respiration rate — single date
python3 {baseDir}/garmin_data.py respiration                  # today
python3 {baseDir}/garmin_data.py respiration --date 2026-01-15

# Body composition (weight, BMI, body fat, muscle mass)
python3 {baseDir}/garmin_data.py body_composition --days 30

# Training readiness scores
python3 {baseDir}/garmin_data.py training_readiness --days 7

# Combined single-day health snapshot (steps, sleep, stress, body battery, HR, etc.)
python3 {baseDir}/garmin_data.py health_snapshot                  # today
python3 {baseDir}/garmin_data.py health_snapshot --date 2026-01-15

# Custom date range — supported by all history commands above
# (summary uses a native date range; the rest fetch enough records to cover the
# window and filter client-side. --start anchors the window; --end defaults to today.)
python3 {baseDir}/garmin_data.py summary --start 2026-01-01 --end 2026-01-31
python3 {baseDir}/garmin_data.py sleep --start 2026-04-01 --end 2026-04-30
python3 {baseDir}/garmin_data.py stress --start 2026-03-01

# Registered devices
python3 {baseDir}/garmin_data.py devices

# User profile
python3 {baseDir}/garmin_data.py profile
```

Output is JSON to stdout. Parse it to answer user questions.

## Answering Questions

| User asks | Action |
|-----------|--------|
| "How many steps did I take?" | `python3 {baseDir}/garmin_data.py summary --days 7`, report steps |
| "How did I sleep?" | `python3 {baseDir}/garmin_data.py sleep --days 7`, report quality + duration |
| "What's my resting heart rate?" | `python3 {baseDir}/garmin_data.py heart_rate --days 7`, report resting HR trend |
| "Is my HRV improving?" | `python3 {baseDir}/garmin_data.py hrv`, analyze the `weekly_avg` + `last_night_value` fields it returns |
| "How stressed am I?" | `python3 {baseDir}/garmin_data.py stress --days 7`, report stress levels |
| "What's my body battery?" | `python3 {baseDir}/garmin_data.py body_battery --days 7`, report charge/drain |
| "Am I ready to train?" | `python3 {baseDir}/garmin_data.py training_readiness --days 7`, report readiness |
| "Show my workouts" | `python3 {baseDir}/garmin_data.py activities --limit 30`, list activities |
| "What's my weight trend?" | `python3 {baseDir}/garmin_data.py body_composition --days 30`, report weight |
| "Give me a health overview" | `python3 {baseDir}/garmin_data.py health_snapshot`, full single-day summary |

## Key Metrics

- **Steps**: Daily step count, distance, calories, active minutes
- **Sleep Score** (0-100): Quality rating (fair <75, good 75-89, excellent 90+)
- **Resting Heart Rate** (bpm): Lower = better cardiovascular fitness
- **HRV** (ms): Higher = better recovery capacity; track weekly average trend
- **Stress** (0-100): calm <30, moderate 30-50, high >50
- **Body Battery** (0-100): Morning value indicates recovery quality
- **Training Readiness** (0-100): low <40, moderate 40-65, high 66-85, prime >85
- **SpO2** (%): Normal 95-100%, concern <93%

## Health Analysis

When the user asks about their health, trends, or wants insights, use `{baseDir}/references/health_analysis.md` for:
- Science-backed interpretation of all Garmin metrics
- Normal ranges by age and fitness level
- Pattern detection (overtraining, sleep debt, stress trends)
- Actionable recommendations based on data
- Red flags that suggest medical consultation

### Analysis workflow
1. Fetch data: `python3 {baseDir}/garmin_data.py health_snapshot` (single day; loop over `--date YYYY-MM-DD` if you need a trend)
2. Read `{baseDir}/references/health_analysis.md` for interpretation framework
3. Apply the 5-step analysis: Status -> Trends -> Patterns -> Insights -> Flags
4. Always include disclaimer that this is not medical advice

## References

- `{baseDir}/references/health_analysis.md` -- science-backed health data interpretation guide
